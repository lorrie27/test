def poc_square(x):

	return x*x