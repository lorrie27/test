from setuptools import setup

setup(name='package1',
      version='1.0',
      description='test pkg 1',
      author='Lorrie Straka',
      author_email='straka.lorrie@gmail.com',
      packages=['test.package1'],
      package_dir={'package1': 'test/package1'}
     )